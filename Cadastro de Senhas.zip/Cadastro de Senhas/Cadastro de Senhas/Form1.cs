﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Cadastro_de_Senhas
{
    public partial class Form1 : Form
    {
        public Form1() //Inicialização do Form
        {
            InitializeComponent();
            ClickEditar();
        }

        private void LimpaCampos() //Limpa campos após manipulação do arquivo
        {
            txtPassword.Clear();
            txtUser.Clear();
        }

        private void ClickEditar()
        {
            pbCadastro.Visible = false;
            pbEditar.Visible = true;
            pnlCadastrar.Visible = false;
            pnlGerenciar.Visible = true;
            string caminho = AppDomain.CurrentDomain.BaseDirectory.ToString() + "senhas.txt";
            lbxSenhas.Items.Clear();

            if (File.Exists(caminho))
            {
                string[] linhas = File.ReadAllLines(caminho);
                lbxSenhas.Items.AddRange(linhas);
                errorProvider1.Clear();
            }
        } //Ação padrão do botão Editar

        static void lineChanger(string newText, string fileName, int line_to_edit)
        {
            string[] arrLine = File.ReadAllLines("senhas.txt");
            arrLine[line_to_edit] = newText;
            File.WriteAllLines("senhas.txt", arrLine);
        }

        string[] split = null;
        int indice = -1;

        private void button1_Click(object sender, EventArgs e)
        {
            string entrada;
            entrada = txtUser.Text + " | " + txtPassword.Text;

            if (txtUser.Enabled == false)
            {
                if (txtPassword.Text.Trim().Length == 0)
                {
                    errorProvider1.SetError(txtPassword, "O Campo Senha não pode estar em branco");
                    return;
                }
                else
                {
                    lineChanger(entrada, "", indice);
                    LimpaCampos();
                    MessageBox.Show("Alterado com sucesso!", "Concluído", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClickEditar();
                }
            }
            else
            {
                if (txtPassword.Text.Trim().Length == 0 || txtUser.Text.Trim().Length == 0)
                {
                    errorProvider1.SetError(txtUser, "Este campo não pode estar em branco");
                    errorProvider1.SetError(txtPassword, "Este campo não pode estar em branco");
                    return;
                }
                else
                {
                    entrada += Environment.NewLine;
                    File.AppendAllText("senhas.txt", entrada);
                    LimpaCampos();

                    MessageBox.Show("Cadastrado com sucesso!", "Concluído", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClickEditar();
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            LimpaCampos();
            ClickEditar();

            MessageBox.Show("Ação Cancelada", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            ClickEditar();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            string caminho = AppDomain.CurrentDomain.BaseDirectory.ToString() + "senhas.txt";
            int indice = lbxSenhas.SelectedIndex;

            if (indice != -1)
            {
                string linha = lbxSenhas.Items[indice].ToString();

                DialogResult dialogResult = MessageBox.Show(string.Format("Deseja remover {0}?", linha),
                                                            "Warning",
                                                            MessageBoxButtons.YesNo,
                                                            MessageBoxIcon.Warning);

                if (dialogResult == DialogResult.Yes)
                {
                    using (var input = File.OpenText(caminho))
                    using (var output = new StreamWriter("tmpSenhas.txt"))
                    {
                        string linhaAtual;
                        while ((linhaAtual = input.ReadLine()) != null)
                        {
                            if (linhaAtual != linha)
                            {
                                output.WriteLine(linhaAtual);
                            }
                        }
                    }

                    lbxSenhas.Items.RemoveAt(indice); // Remove o item selecionado
                    File.Delete(caminho); // Deleta o arquivo original
                    File.Move("tmpSenhas.txt", caminho); // Substitui o original pelo modificado
                }
                else if (dialogResult == DialogResult.No)
                {
                }
            }
        }

        public void btnAlterar_Click(object sender, EventArgs e)
        {

            string caminho = AppDomain.CurrentDomain.BaseDirectory.ToString() + "senhas.txt";
            indice = lbxSenhas.SelectedIndex;

            if (indice != -1)
            {
                string linha = lbxSenhas.Items[indice].ToString();

                DialogResult dialogResult = MessageBox.Show(string.Format("Deseja Alterar {0}?", linha),
                                                            "Warning",
                                                            MessageBoxButtons.YesNo,
                                                            MessageBoxIcon.Warning);

                if (dialogResult == DialogResult.Yes)
                {
                    pnlCadastrar.Visible = true;
                    pnlGerenciar.Visible = false;
                    using (var input = File.OpenText(caminho))
                    using (var output = new StreamWriter("tmpSenhas.txt"))
                    {
                        string linhaAtual;
                        while ((linhaAtual = input.ReadLine()) != null)
                        {
                            if (linhaAtual != linha)
                            {
                                output.WriteLine(linhaAtual);
                            }
                        }

                        split = linha.Split('|');

                        split[1] = txtPassword.Text;

                        txtUser.Enabled = false;
                        txtUser.Text = split[0];
                    }
                }
            }
        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            pbCadastro.Visible = true;
            pbEditar.Visible = false;
            txtPassword.Text = "";
            txtUser.Text = "";
            txtPassword.Enabled = true;
            txtUser.Enabled = true;
            pnlCadastrar.Visible = true;
            pnlGerenciar.Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}